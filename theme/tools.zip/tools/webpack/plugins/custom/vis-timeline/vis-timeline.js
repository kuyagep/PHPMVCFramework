// vis-timeline - An interactive visualization chart to visualize data in time: https://github.com/visjs/vis-timeline

window.vis = require('vis-timeline/standalone');
window.Handlebars = require("handlebars");

require('vis-timeline/dist/vis-timeline-graph2d.css');
