// Tiny slider - for all purposes, inspired by Owl Carousel.

window.tns = require('tiny-slider/src/tiny-slider.js').tns;
