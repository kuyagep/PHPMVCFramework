window.KTModalCreateProjectBudget = require('@/src/js/custom/modals/create-project/bundle/budget.js');
window.KTModalCreateProjectComplete = require('@/src/js/custom/modals/create-project/bundle/complete.js');
window.KTModalCreateProjectFiles = require('@/src/js/custom/modals/create-project/bundle/files.js');
window.KTModalCreateProjectSettings = require('@/src/js/custom/modals/create-project/bundle/settings.js');
window.KTModalCreateProjectTargets = require('@/src/js/custom/modals/create-project/bundle/targets.js');
window.KTModalCreateProjectTeam = require('@/src/js/custom/modals/create-project/bundle/team.js');
window.KTModalCreateProjectType = require('@/src/js/custom/modals/create-project/bundle/type.js');
window.KTModalCreateProject = require('@/src/js/custom/modals/create-project/bundle/main.js');
