window.KTModalOfferADealComplete = require('@/src/js/custom/modals/offer-a-deal/bundle/complete.js');
window.KTModalOfferADealDetails = require('@/src/js/custom/modals/offer-a-deal/bundle/details.js');
window.KTModalOfferADealFinance = require('@/src/js/custom/modals/offer-a-deal/bundle/finance.js');
window.KTModalOfferADealType = require('@/src/js/custom/modals/offer-a-deal/bundle/type.js');
window.KTModalOfferADeal = require('@/src/js/custom/modals/offer-a-deal/bundle/main.js');
